package com.example.menumiegacoan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UdangRambutanAct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_udang_rambutan);
    }
}