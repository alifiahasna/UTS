package com.example.menumiegacoan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EsTuyul extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_es_tuyul);
    }
}