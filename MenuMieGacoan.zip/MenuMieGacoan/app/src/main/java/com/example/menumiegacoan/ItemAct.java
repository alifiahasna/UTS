package com.example.menumiegacoan;

public class ItemAct {
    static int [] iconList = {
            R.drawable.angel, R.drawable.iblis, R.drawable.udangkeju,
            R.drawable.udangrambutan, R.drawable.sundelbolong, R.drawable.tuyul
    };

    static String[] Headline = {
            "Mie Angel", "Mie Iblis", "Udang Keju", "Udang Rambutan",
            "Es Sundel Bolong", "Es Tuyul"
    };
    static String[] Subheadline = {
            "Harga : Rp. 9.500", "Harga : Rp. 9.500 - Rp. 10.500","Harga : Rp. 8.600",
            "Harga : Rp. 8.600", "Harga : Rp. 5.900", "Harga : Rp. 5.900"
    };
}
